# Project Outputs

This folder contains presentation-ready outputs extracted from the saved results in the completed Jupyter Notebook.

## Figures
- `01_average_hourly_solar_vs_usage.png` — original required hourly average profile saved in the notebook.
- `02_monthly_grid_purchases_comparison.png` — monthly grid purchases with and without battery storage.
- `03_monthly_solar_generation_vs_usage.png` — monthly solar generation compared with household usage.
- `04_20_year_annual_savings_projection.png` — projected annual savings under both inflation scenarios.
- `05_investment_appraisal_comparison.png` — NPV and IRR comparison across the two scenarios.

## Tables
- `monthly_energy_summary_2020.csv` — monthly energy summary displayed in the notebook.
- `model_validation_summary.csv` — final validation outputs from the notebook.

## Financial Results
- `20_year_savings_projection_2022_2041.csv` — 20-year projection reconstructed from the final projection logic in the notebook.
- `investment_appraisal_comparison.csv` — final scenario comparison displayed in the notebook.

## Important interpretation note
The final validation cell in the notebook reports annual savings of USD 595.38, NPV of USD 2,430.74 / USD 3,741.72 and IRR of 9.43% / 10.72% for Scenarios 1 / 2 respectively. Earlier exploratory cells contain alternative intermediate results; this export uses the final model validation and final financial comparison.

The hourly average chart is extracted from the saved notebook output. Other charts are generated from the monthly summary and final projection values recorded in the notebook.

These outputs reproduce the notebook's reported results; they do not independently re-run the source workbook.
